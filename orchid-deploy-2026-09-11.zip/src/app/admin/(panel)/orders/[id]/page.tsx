import Link from 'next/link'
import { notFound } from 'next/navigation'

import { Badge, PageHeader, Table, Td, Th } from '@/components/admin/ui'
import { OrderStatusControl, OrderNoteForm } from '@/components/admin/order-controls'
import { PaymentReviewActions } from '@/components/admin/payment-actions'
import { AdminGatewayPaymentStatus } from '@/components/admin/gateway-payment-status'
import { OrderTimeline } from '@/components/admin/order-timeline'
import { CopyField } from '@/components/admin/copy-field'
import { OrderSmsPanel } from '@/components/admin/order-sms-panel'
import { ResponsiveImage } from '@/components/media'
import { storedWidth } from '@/lib/media-url'
import { getForAdmin, timelineForAdmin } from '@/modules/orders/queries'
import { requirePermission } from '@/modules/admin/auth'
import { hasPermission } from '@/lib/permissions'
import {
  ADMIN_TRANSITIONS,
  ORDER_STATUS_LABELS,
  ORDER_STATUS_TONE,
  PAYMENT_STATUS_LABELS,
} from '@/lib/order-status'
import { formatPrice } from '@/lib/money'
import { formatJalaliDateTime } from '@/lib/jalali'
import { toPersianDigits } from '@/lib/persian'

export const dynamic = 'force-dynamic'
export const metadata = { title: 'جزئیات سفارش' }

export default async function AdminOrderDetailPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const admin = await requirePermission('orders.view')
  const { id } = await params

  const orderId = Number(id)
  if (!Number.isInteger(orderId) || orderId <= 0) notFound()

  const order = await getForAdmin(orderId)
  if (!order) notFound()

  const timeline = await timelineForAdmin(orderId)

  const canUpdateStatus = hasPermission(admin, 'orders.update_status')
  const canNote = hasPermission(admin, 'orders.note')
  const canApprove = hasPermission(admin, 'payments.approve')
  const canReject = hasPermission(admin, 'payments.reject')
  const canSendSms = hasPermission(admin, 'sms.approve')

  const isGateway = order.paymentMethod === 'torob_pay' || order.paymentMethod === 'bitpay'
  const nextStatuses = ADMIN_TRANSITIONS[order.status].filter(
    (status) =>
      status !== 'shipped' &&
      (status !== 'paid' || order.paymentStatus === 'approved') &&
      (!isGateway ||
      (status === 'cancelled'
        ? !order.gatewayAttempt || order.gatewayAttempt.status === 'failed'
        : order.paymentStatus === 'approved')),
  )

  return (
    <>
      <div className="mb-2">
        <Link href="/admin/orders" className="text-sm text-accent-2 hover:underline">
          ← سفارش‌ها
        </Link>
      </div>

      <PageHeader
        title={`سفارش ${toPersianDigits(order.orderNumber)}`}
        description={formatJalaliDateTime(order.createdAt)}
        action={
          <div className="flex items-center gap-3">
            <CopyField
              label="شماره سفارش"
              display={toPersianDigits(order.orderNumber)}
              copyValue={order.orderNumber}
            />
            <Badge tone={ORDER_STATUS_TONE[order.status]}>{ORDER_STATUS_LABELS[order.status]}</Badge>
          </div>
        }
      />

      <div className="grid lg:grid-cols-3 gap-6 items-start">
        <div className="lg:col-span-2 space-y-6">
          <section className="card overflow-hidden">
            <h2 className="text-sm text-ink-muted px-4 py-3 bg-surface-sunken">اقلام سفارش</h2>
            <div className="overflow-x-auto">
              <Table>
                <thead>
                  <tr>
                    <Th>محصول</Th>
                    <Th>کد کالا</Th>
                    <Th>قیمت واحد</Th>
                    <Th>تعداد</Th>
                    <Th>جمع</Th>
                  </tr>
                </thead>
                <tbody>
                  {order.items.map((item) => (
                    <tr key={item.id}>
                      <Td>
                        <div className="flex items-center gap-3">
                          {item.imagePath && (
                            <ResponsiveImage
                              path={item.imagePath}
                              alt=""
                              width={storedWidth(item.imagePath)}
                              height={storedWidth(item.imagePath)}
                              sizes="44px"
                              className="h-14 w-11 shrink-0 rounded-[3px] object-cover"
                            />
                          )}
                          <div className="min-w-0">
                            <Link
                              href={`/product/${encodeURIComponent(item.productSlug)}`}
                              target="_blank"
                              rel="noopener"
                              className="text-accent-2 hover:underline"
                            >
                              {item.productName}
                            </Link>
                            {item.variantLabel && (
                              <span className="block text-xs text-ink-subtle mt-0.5">
                                {item.variantLabel}
                              </span>
                            )}
                          </div>
                        </div>
                      </Td>
                      <Td className="text-xs nums" >
                        <span dir="ltr">{item.sku}</span>
                      </Td>
                      <Td className="nums whitespace-nowrap">{formatPrice(item.unitPrice, false)}</Td>
                      <Td className="nums">{toPersianDigits(item.quantity)}</Td>
                      <Td className="nums whitespace-nowrap">{formatPrice(item.lineTotal, false)}</Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </div>

            <dl className="p-4 space-y-2 text-sm border-t border-line">
              <div className="flex justify-between">
                <dt className="text-ink-muted">جمع کالاها</dt>
                <dd className="nums">{formatPrice(order.subtotal)}</dd>
              </div>
              {order.discountTotal > 0 && (
                <div className="flex justify-between text-success">
                  <dt>تخفیف</dt>
                  <dd className="nums">− {formatPrice(order.discountTotal)}</dd>
                </div>
              )}
              {order.shippingTotal > 0 && (
                <div className="flex justify-between">
                  <dt className="text-ink-muted">هزینه ارسال</dt>
                  <dd className="nums">{formatPrice(order.shippingTotal)}</dd>
                </div>
              )}
              <div className="flex justify-between pt-2 mt-2 border-t border-line font-semibold">
                <dt>مبلغ کل</dt>
                <dd className="nums">{formatPrice(order.grandTotal)}</dd>
              </div>
            </dl>
          </section>

          <section className="card p-5">
            <h2 className="text-sm text-ink-muted mb-4">پرداخت</h2>

            {order.payment ? (
              <>
                <dl className="grid sm:grid-cols-2 gap-4 text-sm">
                  <div>
                    <dt className="text-xs text-ink-muted mb-1">وضعیت</dt>
                    <dd>{PAYMENT_STATUS_LABELS[order.payment.status]}</dd>
                  </div>
                  <div>
                    <dt className="text-xs text-ink-muted mb-1">روش</dt>
                    <dd>
                      {order.payment.method === 'card_to_card'
                        ? 'کارت به کارت'
                        : order.payment.method === 'torob_pay'
                          ? 'ترب‌پی'
                          : order.payment.method === 'bitpay'
                            ? 'بیت‌پی'
                            : order.payment.method}
                    </dd>
                  </div>
                  {order.payment.referenceCode ? (
                    <CopyField
                      label="کد رهگیری"
                      display={toPersianDigits(order.payment.referenceCode)}
                      copyValue={order.payment.referenceCode}
                    />
                  ) : (
                    <div>
                      <dt className="text-xs text-ink-muted mb-1">کد رهگیری</dt>
                      <dd className="text-ink-subtle">—</dd>
                    </div>
                  )}
                  <div>
                    <dt className="text-xs text-ink-muted mb-1">زمان ثبت</dt>
                    <dd className="nums text-xs">
                      {order.payment.referenceSubmittedAt
                        ? formatJalaliDateTime(order.payment.referenceSubmittedAt)
                        : '—'}
                    </dd>
                  </div>
                </dl>

                {order.payment.adminNote && (
                  <p className="mt-4 pt-4 border-t border-line text-sm text-ink-muted">
                    یادداشت بررسی: {order.payment.adminNote}
                  </p>
                )}

                {order.payment.status === 'reference_submitted' && (canApprove || canReject) && (
                  <div className="mt-5 pt-4 border-t border-line">
                    <PaymentReviewActions
                      paymentId={order.payment.id}
                      canApprove={canApprove}
                      canReject={canReject}
                    />
                  </div>
                )}

                {isGateway && order.payment.status !== 'approved' && (
                  <AdminGatewayPaymentStatus orderId={order.id} />
                )}

                {isGateway && order.gatewayAttempt && (
                  <dl className="mt-4 grid sm:grid-cols-2 gap-4 border-t border-line pt-4 text-sm">
                    <div>
                      <dt className="text-xs text-ink-muted mb-1">وضعیت درخواست درگاه</dt>
                      <dd>{gatewayAttemptLabel(order.gatewayAttempt.status)}</dd>
                    </div>
                    <div>
                      <dt className="text-xs text-ink-muted mb-1">زمان ایجاد درخواست</dt>
                      <dd className="nums text-xs">
                        {formatJalaliDateTime(order.gatewayAttempt.createdAt)}
                      </dd>
                    </div>
                  </dl>
                )}
              </>
            ) : (
              <p className="text-sm text-ink-subtle">پرداختی ثبت نشده است.</p>
            )}
          </section>

          <OrderSmsPanel
            orderId={order.id}
            orderStatus={order.status}
            company={order.shipmentCompany}
            trackingCode={order.shipmentTrackingCode}
            messages={order.smsMessages as { id: number; event: string; status: string; attempts: number; last_error?: string | null; sent_at?: string | Date | null }[]}
            canSend={canSendSms}
          />
        </div>

        <div className="space-y-6">
          {canUpdateStatus && nextStatuses.length > 0 && (
            <section className="card p-5">
              <h2 className="text-sm text-ink-muted mb-3">تغییر وضعیت</h2>
              <OrderStatusControl
                orderId={order.id}
                options={nextStatuses.map((s) => ({ value: s, label: ORDER_STATUS_LABELS[s] }))}
              />
            </section>
          )}

          <section className="card p-5">
            <h2 className="text-sm text-ink-muted mb-3">مشتری</h2>
            <p className="text-ink font-medium">{order.customer.name || order.shipFullName}</p>
            <p className="text-sm text-ink-muted nums mt-1" dir="ltr">
              {order.customer.phone}
            </p>
            <Link
              href={`/admin/customers?q=${encodeURIComponent(order.customer.phone)}`}
              className="text-xs text-accent-2 hover:underline mt-3 inline-block"
            >
              مشاهده پروفایل مشتری
            </Link>
          </section>

          <section className="card p-5">
            <h2 className="text-sm text-ink-muted mb-3">نشانی تحویل</h2>
            <address className="not-italic text-sm text-ink-muted leading-relaxed space-y-1">
              <p className="text-ink">{order.shipFullName}</p>
              <p className="nums" dir="ltr">
                {order.shipPhone}
              </p>
              <p>
                {order.shipProvince}، {order.shipCity}
              </p>
              <p>{order.shipAddressLine}</p>
            </address>

            <dl className="mt-3 pt-3 border-t border-line">
              <CopyField
                label="کد پستی"
                display={toPersianDigits(order.shipPostalCode)}
                copyValue={order.shipPostalCode}
              />
            </dl>
            {order.customerNote && (
              <p className="mt-3 pt-3 border-t border-line text-sm text-ink-muted">
                یادداشت مشتری: {order.customerNote}
              </p>
            )}
          </section>

          <section className="card p-5">
            <h2 className="text-sm text-ink-muted mb-4">تاریخچه سفارش</h2>
            <OrderTimeline events={timeline} />
          </section>

          {canNote && (
            <section className="card p-5">
              <h2 className="text-sm text-ink-muted mb-3">یادداشت داخلی</h2>
              <p className="text-xs text-ink-subtle mb-3">
                این یادداشت هرگز به مشتری نمایش داده نمی‌شود.
              </p>
              <OrderNoteForm orderId={order.id} current={order.internalNote ?? ''} />
            </section>
          )}
        </div>
      </div>
    </>
  )
}

function gatewayAttemptLabel(status: string): string {
  const labels: Record<string, string> = {
    creating: 'در حال ایجاد',
    pending: 'در انتظار نتیجه',
    review: 'نیازمند بررسی',
    paid: 'تأیید شده',
    failed: 'ناموفق',
  }
  return labels[status] ?? status
}
